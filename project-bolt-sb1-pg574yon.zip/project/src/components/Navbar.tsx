import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Lightbulb, Package, Users, Calendar, LogOut } from 'lucide-react';
import { supabase } from '../lib/supabase';

export default function Navbar() {
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate('/auth');
  };

  return (
    <nav className="bg-white shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-2">
            <Lightbulb className="h-8 w-8 text-yellow-500" />
            <span className="text-xl font-bold">Lighting Rental</span>
          </Link>
          
          <div className="hidden md:flex space-x-8">
            <Link to="/" className="flex items-center space-x-1 text-gray-700 hover:text-yellow-500">
              <Package className="h-5 w-5" />
              <span>Equipment</span>
            </Link>
            <Link to="/rentals" className="flex items-center space-x-1 text-gray-700 hover:text-yellow-500">
              <Calendar className="h-5 w-5" />
              <span>Rentals</span>
            </Link>
            <Link to="/customers" className="flex items-center space-x-1 text-gray-700 hover:text-yellow-500">
              <Users className="h-5 w-5" />
              <span>Customers</span>
            </Link>
          </div>

          <button
            onClick={handleSignOut}
            className="flex items-center space-x-1 text-gray-700 hover:text-red-500"
          >
            <LogOut className="h-5 w-5" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>
    </nav>
  );
}