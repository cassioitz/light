import React, { useState, useEffect } from 'react';
import { Plus } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface Equipment {
  id: string;
  name: string;
  description: string;
  stock_quantity: number;
  daily_rate: number;
}

export default function Equipment() {
  const [equipment, setEquipment] = useState<Equipment[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchEquipment();
  }, []);

  async function fetchEquipment() {
    try {
      const { data, error } = await supabase
        .from('equipment')
        .select('*')
        .order('name');

      if (error) throw error;
      setEquipment(data || []);
    } catch (error) {
      console.error('Error fetching equipment:', error);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Equipment</h1>
        <button className="bg-yellow-500 text-white px-4 py-2 rounded-md flex items-center space-x-2 hover:bg-yellow-600">
          <Plus className="h-5 w-5" />
          <span>Add Equipment</span>
        </button>
      </div>

      {loading ? (
        <div className="text-center py-4">Loading equipment...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {equipment.map((item) => (
            <div key={item.id} className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold text-gray-900">{item.name}</h3>
              <p className="text-gray-600 mt-2">{item.description}</p>
              <div className="mt-4 flex justify-between items-center">
                <div className="text-sm text-gray-500">
                  In Stock: {item.stock_quantity}
                </div>
                <div className="text-yellow-600 font-semibold">
                  ${item.daily_rate}/day
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}