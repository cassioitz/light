import React from 'react';
import { Package, Calendar, Users } from 'lucide-react';

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center space-x-3">
            <Package className="h-8 w-8 text-yellow-500" />
            <h2 className="text-xl font-semibold text-gray-900">Equipment</h2>
          </div>
          <p className="mt-2 text-gray-600">Manage your lighting equipment inventory</p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center space-x-3">
            <Calendar className="h-8 w-8 text-yellow-500" />
            <h2 className="text-xl font-semibold text-gray-900">Rentals</h2>
          </div>
          <p className="mt-2 text-gray-600">Track active and upcoming rentals</p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center space-x-3">
            <Users className="h-8 w-8 text-yellow-500" />
            <h2 className="text-xl font-semibold text-gray-900">Customers</h2>
          </div>
          <p className="mt-2 text-gray-600">Manage your customer database</p>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Recent Activity</h2>
        <div className="space-y-4">
          <p className="text-gray-600">Loading recent activity...</p>
        </div>
      </div>
    </div>
  );
}