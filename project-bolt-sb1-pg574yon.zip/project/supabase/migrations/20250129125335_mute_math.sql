/*
  # Initial Schema for Lighting Equipment Rental System

  1. New Tables
    - `equipment`
      - `id` (uuid, primary key)
      - `name` (text): Equipment name
      - `description` (text): Detailed description
      - `stock_quantity` (integer): Available quantity
      - `daily_rate` (decimal): Daily rental rate
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `customers`
      - `id` (uuid, primary key)
      - `name` (text): Customer name
      - `email` (text): Customer email
      - `phone` (text): Contact phone
      - `created_at` (timestamp)
      - `user_id` (uuid): Reference to auth.users
    
    - `rentals`
      - `id` (uuid, primary key)
      - `customer_id` (uuid): Reference to customers
      - `equipment_id` (uuid): Reference to equipment
      - `pickup_date` (timestamp): Pickup date
      - `return_date` (timestamp): Expected return date
      - `actual_return_date` (timestamp): Actual return date
      - `status` (text): Rental status
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Equipment table
CREATE TABLE equipment (
    id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    name text NOT NULL,
    description text,
    stock_quantity integer NOT NULL DEFAULT 0,
    daily_rate decimal(10,2) NOT NULL,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now()
);

-- Customers table
CREATE TABLE customers (
    id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id uuid REFERENCES auth.users,
    name text NOT NULL,
    email text NOT NULL UNIQUE,
    phone text,
    created_at timestamptz DEFAULT now()
);

-- Rentals table
CREATE TABLE rentals (
    id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    customer_id uuid REFERENCES customers(id) ON DELETE CASCADE,
    equipment_id uuid REFERENCES equipment(id) ON DELETE CASCADE,
    pickup_date timestamptz NOT NULL,
    return_date timestamptz NOT NULL,
    actual_return_date timestamptz,
    status text NOT NULL CHECK (status IN ('active', 'completed', 'cancelled')) DEFAULT 'active',
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE equipment ENABLE ROW LEVEL SECURITY;
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE rentals ENABLE ROW LEVEL SECURITY;

-- Policies for equipment
CREATE POLICY "Allow read access to equipment for authenticated users"
    ON equipment FOR SELECT
    TO authenticated
    USING (true);

CREATE POLICY "Allow insert access to equipment for authenticated users"
    ON equipment FOR INSERT
    TO authenticated
    WITH CHECK (true);

CREATE POLICY "Allow update access to equipment for authenticated users"
    ON equipment FOR UPDATE
    TO authenticated
    USING (true);

-- Policies for customers
CREATE POLICY "Users can view their own customer profile"
    ON customers FOR SELECT
    TO authenticated
    USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own customer profile"
    ON customers FOR UPDATE
    TO authenticated
    USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own customer profile"
    ON customers FOR INSERT
    TO authenticated
    WITH CHECK (auth.uid() = user_id);

-- Policies for rentals
CREATE POLICY "Users can view their own rentals"
    ON rentals FOR SELECT
    TO authenticated
    USING (
        customer_id IN (
            SELECT id FROM customers WHERE user_id = auth.uid()
        )
    );

CREATE POLICY "Users can create their own rentals"
    ON rentals FOR INSERT
    TO authenticated
    WITH CHECK (
        customer_id IN (
            SELECT id FROM customers WHERE user_id = auth.uid()
        )
    );

CREATE POLICY "Users can update their own rentals"
    ON rentals FOR UPDATE
    TO authenticated
    USING (
        customer_id IN (
            SELECT id FROM customers WHERE user_id = auth.uid()
        )
    );

-- Function to update equipment stock when rental is created
CREATE OR REPLACE FUNCTION update_equipment_stock()
RETURNS TRIGGER AS $$
BEGIN
    IF (TG_OP = 'INSERT' AND NEW.status = 'active') THEN
        UPDATE equipment
        SET stock_quantity = stock_quantity - 1
        WHERE id = NEW.equipment_id;
    ELSIF (TG_OP = 'UPDATE' AND NEW.status = 'completed' AND OLD.status = 'active') THEN
        UPDATE equipment
        SET stock_quantity = stock_quantity + 1
        WHERE id = NEW.equipment_id;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for equipment stock management
CREATE TRIGGER manage_equipment_stock
    AFTER INSERT OR UPDATE ON rentals
    FOR EACH ROW
    EXECUTE FUNCTION update_equipment_stock();

-- Function to update timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers for updating timestamps
CREATE TRIGGER update_equipment_updated_at
    BEFORE UPDATE ON equipment
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_rentals_updated_at
    BEFORE UPDATE ON rentals
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();